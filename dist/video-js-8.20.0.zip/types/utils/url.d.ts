export function parseUrl(url: string): URL;
export function getAbsoluteURL(url: string): string;
export function getFileExtension(path: string): string;
export function isCrossOrigin(url: string, winLoc?: URL): boolean;
//# sourceMappingURL=url.d.ts.map